# Amazon-Clone-01
A frontend clone of E-commerce website of Amazon. This is created using HTML,CSS and Vanilla Javascript. The page is created for big screens i.e, laptops, PCs only.

# Technologies:
* HTML5
* CSS3
* CSS Animations
* Javascript
* Netlify

# Live Link:
https://amazon-frontend-clone01.netlify.app/
